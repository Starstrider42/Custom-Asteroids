var files =
[
    [ "OrbitManager.cs", "_orbit_manager_8cs.html", [
      [ "OrbitManager", "class_starstrider42_1_1_custom_asteroids_1_1_orbit_manager.html", "class_starstrider42_1_1_custom_asteroids_1_1_orbit_manager" ],
      [ "BadPopulationException", "class_starstrider42_1_1_custom_asteroids_1_1_orbit_manager_1_1_bad_population_exception.html", "class_starstrider42_1_1_custom_asteroids_1_1_orbit_manager_1_1_bad_population_exception" ],
      [ "PopulationLoader", "class_starstrider42_1_1_custom_asteroids_1_1_population_loader.html", "class_starstrider42_1_1_custom_asteroids_1_1_population_loader" ]
    ] ],
    [ "Population.cs", "_population_8cs.html", [
      [ "Population", "class_starstrider42_1_1_custom_asteroids_1_1_population.html", "class_starstrider42_1_1_custom_asteroids_1_1_population" ]
    ] ],
    [ "Random.cs", "_random_8cs.html", [
      [ "Pair< T, U >", "class_starstrider42_1_1_custom_asteroids_1_1_pair_3_01_t_00_01_u_01_4.html", "class_starstrider42_1_1_custom_asteroids_1_1_pair_3_01_t_00_01_u_01_4" ],
      [ "RandomDist", "class_starstrider42_1_1_custom_asteroids_1_1_random_dist.html", "class_starstrider42_1_1_custom_asteroids_1_1_random_dist" ]
    ] ],
    [ "SpawnCatcher.cs", "_spawn_catcher_8cs.html", [
      [ "SpawnCatcher", "class_starstrider42_1_1_custom_asteroids_1_1_spawn_catcher.html", "class_starstrider42_1_1_custom_asteroids_1_1_spawn_catcher" ]
    ] ]
];