var hierarchy =
[
    [ "InvalidOperationException", null, [
      [ "OrbitManager.BadPopulationException", "class_starstrider42_1_1_custom_asteroids_1_1_orbit_manager_1_1_bad_population_exception.html", null ]
    ] ],
    [ "MonoBehaviour", null, [
      [ "SpawnCatcher", "class_starstrider42_1_1_custom_asteroids_1_1_spawn_catcher.html", null ]
    ] ],
    [ "OrbitManager", "class_starstrider42_1_1_custom_asteroids_1_1_orbit_manager.html", null ],
    [ "Pair< T, U >", "class_starstrider42_1_1_custom_asteroids_1_1_pair_3_01_t_00_01_u_01_4.html", null ],
    [ "Population", "class_starstrider42_1_1_custom_asteroids_1_1_population.html", null ],
    [ "PopulationLoader", "class_starstrider42_1_1_custom_asteroids_1_1_population_loader.html", null ],
    [ "RandomDist", "class_starstrider42_1_1_custom_asteroids_1_1_random_dist.html", null ]
];