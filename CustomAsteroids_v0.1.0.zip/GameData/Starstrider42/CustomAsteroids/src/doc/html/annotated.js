var annotated =
[
    [ "Starstrider42", "namespace_starstrider42.html", "namespace_starstrider42" ]
];