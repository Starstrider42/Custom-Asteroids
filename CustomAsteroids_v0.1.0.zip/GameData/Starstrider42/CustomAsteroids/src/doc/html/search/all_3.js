var searchData=
[
  ['first',['First',['../class_starstrider42_1_1_custom_asteroids_1_1_pair_3_01_t_00_01_u_01_4.html#a2552c392770a9e6ead8811bc5a31429b',1,'Starstrider42::CustomAsteroids::Pair&lt; T, U &gt;']]]
];
