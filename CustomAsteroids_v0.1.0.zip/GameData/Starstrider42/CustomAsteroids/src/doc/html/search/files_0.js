var searchData=
[
  ['changelog_2emd',['CHANGELOG.md',['../_c_h_a_n_g_e_l_o_g_8md.html',1,'']]],
  ['customization_2emd',['CUSTOMIZATION.md',['../_c_u_s_t_o_m_i_z_a_t_i_o_n_8md.html',1,'']]]
];
