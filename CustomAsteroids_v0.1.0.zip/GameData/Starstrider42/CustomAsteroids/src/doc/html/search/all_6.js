var searchData=
[
  ['makeorbit',['makeOrbit',['../class_starstrider42_1_1_custom_asteroids_1_1_orbit_manager.html#a0c2e2535b09bb318bff8b6991e96832d',1,'Starstrider42::CustomAsteroids::OrbitManager']]]
];
