var searchData=
[
  ['second',['Second',['../class_starstrider42_1_1_custom_asteroids_1_1_pair_3_01_t_00_01_u_01_4.html#abf406b9a194f0bcb9b120ce150774fce',1,'Starstrider42::CustomAsteroids::Pair&lt; T, U &gt;']]]
];
