var class_starstrider42_1_1_custom_asteroids_1_1_orbit_manager =
[
    [ "BadPopulationException", "class_starstrider42_1_1_custom_asteroids_1_1_orbit_manager_1_1_bad_population_exception.html", "class_starstrider42_1_1_custom_asteroids_1_1_orbit_manager_1_1_bad_population_exception" ],
    [ "makeOrbit", "class_starstrider42_1_1_custom_asteroids_1_1_orbit_manager.html#a0c2e2535b09bb318bff8b6991e96832d", null ]
];