Version History                         {#changelog}
============

Custom Biomes conforms to version 2.0.0 of the [Semantic Versioning specification](http://semver.org/spec/v2.0.0.html). 
All version numbers are to be interpreted as described therein. Since Custom Biomes does not expose public functions, the [format of `asteroids.cfg`](@ref newbelts) will be considered the API for the purpose of versioning.

Version 0.1.0
------------
* Initial Release
